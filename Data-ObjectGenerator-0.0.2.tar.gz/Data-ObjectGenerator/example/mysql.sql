use test;
create table mogumogu (user_id INT, user_name VARCHAR(16), time BIGINT, tag VARCHAR(16), type VARCHAR(16), register_hour BIGINT, average DOUBLE);
